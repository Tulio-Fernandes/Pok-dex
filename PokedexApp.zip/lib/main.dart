import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import 'package:flutter/material.dart';
import 'package:pokedex/firebase_options.dart';

import 'package:pokedex/firebase_options.dart';
import 'package:pokedex/pages/login_pages.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
        apiKey: "AIzaSyA9hjLt60qWoeSzHNHUptW1ry-zzjzzEwk",
        authDomain: "pokedex-app-da1f7.firebaseapp.com",
        projectId: "pokedex-app-da1f7",
        storageBucket: "pokedex-app-da1f7.firebasestorage.app",
        messagingSenderId: "84317991758",
        appId: "1:84317991758:web:90aa3aab65c9a7ee79641f"),
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginPage(),
    );
  }
}
